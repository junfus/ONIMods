﻿using Newtonsoft.Json;
using PeterHan.PLib.Options;

namespace $safeprojectname$
{
    [JsonObject(MemberSerialization.OptIn)]
    [RestartRequired]
    public sealed class Options : SingletonOptions<Options>
    {
        [Option]
        [Limit(10, 200)]
        [JsonProperty]
        public int OptionOne { get; set; }

        public Options()
        {
            OptionOne = 50;
        }
    }
}
