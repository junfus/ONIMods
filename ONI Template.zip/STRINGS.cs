﻿namespace $safeprojectname$
{
    public class STRINGS
    {
        // Change class name to namespace (all upper strings).
        public class TEMPLATE
        {
            public class OPTIONS
            {
                public class OPTIONONE
                {
                    public static LocString NAME = "Option One";
                    public static LocString TOOLTIP = "";
                }
            }
        }
    }
}
